import CommonHeader from "@/app/components/CommonHeader";
import CategoryMain from "./categoryComponents/categoryMain";
import {Metadata} from "next";
import {extractIdFromSlug} from "@/utils/categorySlug";
import {getCategoryById} from "@/api/category-api";
import CommonFooter from "@/app/components/CommonFooter";
import React from "react";

export async function generateMetadata({params}: { params: { categorySlug: string }
}): Promise<Metadata> {
    const categoryId = extractIdFromSlug(params.categorySlug);

    try {
        const category = await getCategoryById(categoryId);

        return {
            title: `${category.name} | The Clique`,
            description: category.description || `${category.name} - Shop now at The Clique`,
            openGraph: {
                title: category.name,
                description: category.description,
            },
        };
    } catch (error) {
        return {
            title: 'Category Not Found',
            description: 'The requested Category could not be found',
        };
    }
}

export default async function CategoryPage({params}: { params: { categorySlug: string } }) {
    const id = extractIdFromSlug(params.categorySlug);
    return (
        <div>
            <CommonHeader
                categoryVisibility={"visible"}
                searchBarWidth={"64"}
                isSearchAvailable={true}
            />
            <CategoryMain categoryId={id} />
            <footer>
                <CommonFooter height={"h-14"}/>
            </footer>
        </div>
    );
}